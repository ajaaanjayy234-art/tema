export default {
    TERMINAL_PRELUDE: 'container@nookure~ ',
};
